package units;

public class Entrada {

    private float magnitud;
    private Longitud dimensional;
    
    Entrada(){
        
    }
    
}