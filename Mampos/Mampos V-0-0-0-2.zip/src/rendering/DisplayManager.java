package rendering;



public class DisplayManager {
    
    public static void createDisplay(){
        
    }
    
    public static void updateDisplay(){}
    
    public static void closeDisplay(){}
    
}
