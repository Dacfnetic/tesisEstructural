package components;

import java.util.ArrayList;
import java.util.List;
import rendering.Controlador;

public class ControladorDePlanos extends Controlador{
    
    public static List<Plane> planos = new ArrayList<>();
    public static final Plane temporal = new Plane();
     
}