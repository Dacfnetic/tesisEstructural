package components;

import java.util.ArrayList;
import java.util.List;
import rendering.Controlador;

public class ControladorDeLosas extends Controlador{
    
    public static List<Losa> losas = new ArrayList<>();
    public static final Losa temporal = new Losa();
    
}